export const environment = {
  production: true,
  apiUrl: '/api', // In production, the API is served from the same domain
  version: '1.0.0',
};