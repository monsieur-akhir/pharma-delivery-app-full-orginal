export const environment = {
  production: false,
  apiUrl: '/api', // Using proxy.conf.json to forward to backend
  version: '1.0.0',
};