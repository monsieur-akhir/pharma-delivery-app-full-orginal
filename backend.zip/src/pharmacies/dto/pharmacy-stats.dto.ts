export class PharmacyStatsDto {
  total: number;
  pending: number;
  approved: number;
  pendingInfo: number;
  rejected: number;
}