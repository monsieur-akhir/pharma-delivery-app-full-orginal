export enum NotificationType {
  ORDER = 'order',
  SYSTEM = 'system',
  PHARMACY = 'pharmacy',
  ALERT = 'alert',
  USER = 'user',
  PAYMENT = 'payment',
  DELIVERY = 'delivery',
  PRESCRIPTION = 'prescription',
  MEDICINE = 'medicine',
  REMINDER = 'reminder'
}